package com.rasool.example.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rasool.example.entity.Product;
import com.rasool.example.repository.ProductRepository;
/**
 * @author Rasool Malik Vempalli
 */
@Service
public class ProductService {

    private final ProductRepository repository;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public void deleteAllProducts() {
        repository.deleteAll();
    }

    public Product saveProduct(Product product) {
        return repository.save(product);
    }

    public List<Product> saveProducts(List<Product> products) {
        return repository.saveAll(products);
    }

    public List<Product> getProducts() {
        return repository.findAll();
    }

    public Optional<Product> getProductById(int id) {
        return repository.findById(id);
    }

    public List<Product> getProductByName(String name) {
        return repository.findByName(name.trim()); 
    }

    public void deleteProduct(int id) {
        repository.deleteById(id);
    }

    public void deleteProductWithName(String name) {
        repository.deleteByName(name);
    }

    public Product updateProduct(Product product) {
        return repository.findById(product.getId())
                         .map(existingProduct -> {
                             existingProduct.setName(product.getName());
                             existingProduct.setQuantity(product.getQuantity());
                             existingProduct.setPrice(product.getPrice());
                             return repository.save(existingProduct);
                         })
                         .orElseGet(() -> {
                             return product;
                         });
    }
}

