
package com.rasool.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.rasool.example.entity.Product;
import com.rasool.example.service.ProductService;
/**
 * @author Rasool Malik Vempalli
 */
@RestController
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @PostMapping("/addProduct")
    public ResponseEntity<Product> addProduct(@RequestBody Product product) {
        Product savedProduct = service.saveProduct(product);
        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
    }

    @PostMapping("/addProducts")
    public ResponseEntity<List<Product>> addProducts(@RequestBody List<Product> products) {
        List<Product> savedProducts = service.saveProducts(products);
        return new ResponseEntity<>(savedProducts, HttpStatus.CREATED);
    }

    @GetMapping("/products")
    public ResponseEntity<List<Product>> findAllProducts() {
        List<Product> products = service.getProducts();
        return ResponseEntity.ok(products);
    }

    @GetMapping("/productById/{id}")
    public ResponseEntity<Optional<Product>> findProductById(@PathVariable int id) {
        Optional<Product> product = service.getProductById(id);
        return product != null ? ResponseEntity.ok(product) : ResponseEntity.notFound().build();
    }

    @GetMapping("/product/{name}")
    public ResponseEntity<List<Product>> findProductByName(@PathVariable String name) {
        List<Product> products = service.getProductByName(name);
        return ResponseEntity.ok(products);
    }

    @PutMapping("/update")
    public ResponseEntity<Product> updateProduct(@RequestBody Product product) {
        Product updatedProduct = service.updateProduct(product);
        return ResponseEntity.ok(updatedProduct);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable int id) {
        service.deleteProduct(id);
        return ResponseEntity.ok("Product removed !! " + id);
    }

    @DeleteMapping("/deletebyName/{name}")
    public ResponseEntity<String> deleteProductWithName(@PathVariable String name) {
        service.deleteProductWithName(name);
        return ResponseEntity.ok("Product named '" + name + "' has been removed.");
    }

    @DeleteMapping("/deleteAllProducts")
    public ResponseEntity<Void> deleteAllProducts() {
        service.deleteAllProducts();
        return ResponseEntity.noContent().build();
    }
}

